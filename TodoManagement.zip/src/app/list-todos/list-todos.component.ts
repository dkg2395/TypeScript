import { Component, OnInit } from '@angular/core';

export class ToDo{
  constructor(
public id:number,
public description:string,
public done:boolean,
public targetDate: Date

  ){}
}
@Component({
  selector: 'app-list-todos',
  templateUrl: './list-todos.component.html',
  styleUrls: ['./list-todos.component.css']
})
export class ListTodosComponent implements OnInit {

  todos=[
    new ToDo(1,'Learn to Dance',false,new Date()),
    new ToDo(2,'Learn to Java',false,new Date()),
    new ToDo(3,'Learn to Angular',false,new Date())


    // {id:1,description:'learn to dance'},
    // {id:2,description:'learn to dance'},

    // {id:3,description:'learn to dance'}

  ]

  // todo={

  //   id:1,
  //   description:'Learn to Dance'
  // }

  constructor() { }

  ngOnInit(): void {
  }

}
